package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="review")
public class Review {

	  
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name="name")
    @NotBlank(message = "Review Name is mandatory")
	private String name;
	@Column(name="data")
    @NotBlank(message = "Invalid cannot be empty")
	private String data;
	@Column(name="comment")
	private String comment;
	@Column(name="rating")
	@Max(10)
	@Min(0)
	private int rating;
	@Column(name="pid")
	private int pid;
	
	public Review() {}
	public Review(int id, String name, String data, String comment, int rating, int pid) {
		super();
		this.id = id;
		this.name = name;
		this.data = data;
		this.comment = comment;
		this.rating = rating;
		this.pid = pid;
	}
	
	public Review(String name, String data, String comment, int rating, int pid) {
		super();
		this.name = name;
		this.data = data;
		this.comment = comment;
		this.rating = rating;
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "Review [id=" + id + ", name=" + name + ", data=" + data + ", comment=" + comment + ", rating=" + rating
				+ ", pid=" + pid + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}

}
