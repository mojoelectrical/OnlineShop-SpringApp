package com.example.demo;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReviewService {

	@Autowired
	ReviewRepository  reviewRepository;
	//gets all reviews
	public Iterable<Review> getAll(){
		
		return reviewRepository.findAll();
	}
	// saves reviews
	public Review save(Review review){
		
		return reviewRepository.save(review);
	}
	//updates product
	public Review update(Review review) {
		
		return reviewRepository.save(review);
	}
	
	public void delete(Review review) {
		
		reviewRepository.delete(review);;
	}
	
	public Optional<Review> getReviewById(int id) {
		return reviewRepository.findById(id);
		
	}
	
}
