package com.example.demo;

import com.example.demo.Review;
import com.example.demo.Product;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HtmlController {

	ReviewService reviewService;
	
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ReviewRepository reviewRepository;

	List<Review> temps = new ArrayList<Review>();
	List<Review> reviews = new ArrayList<Review>();
	List<Integer> ids = new ArrayList<Integer>();

	// To get the product page

	// To get the product page
	@GetMapping("/")
	public String home(Product product) {
		return "index";
	}

	// add the Product info
	@PostMapping("/")
	public String add(@Valid Product product, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result);
			return "index";
		}

		productRepository.save(product);
		System.out.println(product.toString());
		// ids.add(product.getId());
		model.addAttribute("products", productRepository.findAll());
		return "detail";
	}

	@GetMapping("/review")
	public String rev(Review review, Model model) {

		model.addAttribute("products", productRepository.findAll());
		return "index2";
	}

	@PostMapping("/add2")
	public String add2(@Valid Review review, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result);
			return "index2";
		}

		reviewRepository.save(review);
		System.out.println(review.toString());
		model.addAttribute("products", productRepository.findAll());
		model.addAttribute("reviews", reviewRepository.findAll());
		return "reviewdetail";
	}

	@RequestMapping("/findid")
	public String getchosenId(@RequestParam(required = false, name = "id") String id, Model m) {
		m.addAttribute("id", id);
		// fills the select id dropdown
		ids.clear();
		Iterable<Product> products = productRepository.findAll();
		for (Product i : products) {
			ids.add(i.getId());
		}

		// adds the list of IDs
		m.addAttribute("ids", ids);
		temps.clear();
		// fills the temporary list with Reviews that match the returned ID
		Iterable<Review> rev = reviewRepository.findAll();
		if (id != null) {
			for (Review r : rev) {
				if (Integer.parseInt(id) == r.getPid()) {
					temps.add(r);
				}
			}
		}
		// Sends the temporary list of reviews to the HTML
		m.addAttribute("temps", temps);
		return "showreviews";
	}

}
