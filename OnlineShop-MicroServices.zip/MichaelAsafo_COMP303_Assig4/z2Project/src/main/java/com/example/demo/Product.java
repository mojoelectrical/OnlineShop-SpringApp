package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="product")
public class Product {
  
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	public Product() {}
	
	public Product(int id, String name, int quantity, String location) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.location = location;
	}
	
	public Product(String name, int quantity, String location) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.location = location;
	}
	@Column(name="name")
    @NotBlank(message = "Product Name is mandatory")
	private String name;
	@Column(name="quantity")
	@Max(50)
	private int quantity;
	@Column(name="location")
    @NotBlank(message = "Location is mandatory")
	private String location;
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", quantity=" + quantity + ", location=" + location + "]";
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}


}
