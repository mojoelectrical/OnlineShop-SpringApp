package com.example.demo;
import com.example.demo.MainController;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.Review;

public interface ReviewRepository extends CrudRepository<Review,Integer>{

}
