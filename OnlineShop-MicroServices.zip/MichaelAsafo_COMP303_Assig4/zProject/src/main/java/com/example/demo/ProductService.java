package com.example.demo;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

	@Autowired
	ProductRepository  productRepository;
	//gets all products
	public Iterable<Product> getAll(){
		
		return productRepository.findAll();
	}
	// saves products
	public Product save(Product product){
		
		return productRepository.save(product);
	}
	//updates product
	public Product update(Product product) {
		
		return productRepository.save(product);
	}
	
	public void delete(Product product) {
		
		productRepository.delete(product);;
	}
	
	public Optional<Product> getProdById(int id) {
		return productRepository.findById(id);
		
	}
	
}
