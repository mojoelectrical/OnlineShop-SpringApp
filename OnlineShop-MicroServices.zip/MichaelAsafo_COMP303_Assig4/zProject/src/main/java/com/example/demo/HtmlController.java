package com.example.demo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HtmlController {

	@Autowired
	private ProductRepository productRepository;

	// To get the product page

	// To get the product page
	@GetMapping("/open")
	public String home(Product product) {
		return "index";
	}

	// add the Product info
	@PostMapping("/open")
	public String add(@Valid Product product, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result);
			return "index";
		}

		productRepository.save(product);
		model.addAttribute("products", productRepository.findAll());
		return "detail";
	}
}
