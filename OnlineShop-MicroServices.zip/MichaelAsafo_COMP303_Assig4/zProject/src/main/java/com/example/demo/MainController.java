package com.example.demo;


import com.example.demo.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RequestMapping("/products")
@RestController
public class MainController {

	@Autowired
	ProductService productService;
	
	@Autowired
	private ProductRepository productRepository;

	List<Product> allproducts = new ArrayList<Product>();

	List<Integer> ids = new ArrayList<Integer>();
	
	@GetMapping
	public Iterable<Product> getAllp(){
		return productService.getAll();
	}
	@PostMapping           //postmapping is saving
	public Product save(@RequestBody Product product, Model model) { //request body returns the object
		productRepository.save(product);
		model.addAttribute("products", productRepository.findAll());
		return productService.save(product);
		
	}
	@PutMapping           //updating same
	public Product update(@RequestBody Product product) {
		return productService.update(product);
	}
	@GetMapping("/{id}")
	public Optional<Product> getById(@PathVariable("id") int id) {
		
		return productService.getProdById(id);
	}
	

}
